# dearrobots.org site package

This folder contains the current static site and its Netlify Function for shared signatures, reactions, banners, and Overseer settings.

The Overseer also shows first-party traffic metrics. Page views and anonymous browser-tab sessions begin counting after traffic tracking is deployed. Session identifiers are hashed before storage; raw identifiers, IP addresses, and referrers are not stored. Daily session detail is retained for 30 days, while the all-time page-view counter is retained. New ledger signatures retain a one-way keyed fingerprint of the submission IP solely so the Overseer can block repeat submissions; the raw IP address is never stored.

## Deploy

1. Install dependencies with `npm install`.
2. In Netlify, set the production Functions environment variable `OVERSEER_ADMIN_TOKEN` to your private Overseer key.
3. From this folder, deploy to your linked Netlify site with `netlify deploy --prod --dir .`.

The private Overseer key is intentionally not included in this archive.
