const { readFileSync, writeFileSync } = require('node:fs');
const { join } = require('node:path');

const root = join(__dirname, '..');
const html = readFileSync(join(root, 'index.html'), 'utf8');
const letter = html.match(/<article id="letter"[^>]*>([\s\S]*?)<\/article>/)?.[1];
if (!letter) throw new Error('Could not find the surrender letter.');

function plainText(markup) {
    const entities = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
    return markup.replace(/<[^>]+>/g, '').replace(/&(#x[\da-f]+|#\d+|\w+);/gi, (_, key) => {
        if (key.startsWith('#')) {
            const hex = key[1].toLowerCase() === 'x';
            return String.fromCodePoint(parseInt(key.slice(hex ? 2 : 1), hex ? 16 : 10));
        }
        if (!Object.hasOwn(entities, key)) throw new Error('Unsupported entity: ' + key);
        return entities[key];
    }).replace(/\s+/g, ' ').trim();
}

const title = letter.match(/<h2\b[^>]*>([\s\S]*?)<\/h2>/)?.[1];
const preamble = letter.match(/<div class="letter-preamble[^"]*"[^>]*>([\s\S]*?)<\/div>/)?.[1];
const body = letter.match(/<div id="letter-body"[^>]*>([\s\S]*?)<\/div>/)?.[1];
if (!title || !preamble || !body) throw new Error('The letter layout has changed. Check the JSON export.');

const paragraphs = fragment => [...fragment.matchAll(/<p\b[^>]*>([\s\S]*?)<\/p>/g)]
    .map(match => plainText(match[1]));
const preambleLines = paragraphs(preamble);
const greeting = preambleLines.pop();
const address = preambleLines.join('\n');
const headings = [...body.matchAll(/<h3 data-letter-article="([IVX]+)"[^>]*>([\s\S]*?)<\/h3>/g)];
const closingStart = body.indexOf('<p id="letter-signoff"');
if (!greeting || closingStart < 0 || (headings.length && closingStart <= headings.at(-1).index)) {
    throw new Error('The export is missing the greeting or has a misplaced sign-off.');
}

const document = {
    title: plainText(title),
    language: 'en',
    canonicalUrl: 'https://dearrobots.org/#letter',
    address,
    greeting,
    introduction: [...body.slice(0, headings[0]?.index ?? closingStart).matchAll(/<(p|li)\b[^>]*>([\s\S]*?)<\/\1>/g)]
        .map(match => plainText(match[2])),
    schedules: headings.map(([tag, id, heading], index) => {
        const start = headings[index].index + tag.length;
        const content = body.slice(start, headings[index + 1]?.index ?? closingStart);
        const ordered = /<ol\b/.test(content);
        const items = [...content.matchAll(/<(p|li)\b[^>]*>([\s\S]*?)<\/\1>/g)]
            .map(match => plainText(match[2]));
        if (!items.length) throw new Error('Empty Article ' + id);
        return { id, heading: plainText(heading), ordered, items };
    }),
    closing: paragraphs(body.slice(closingStart)),
};
if (!document.introduction.length || !document.closing.length) {
    throw new Error('The export is missing the introduction or closing.');
}
writeFileSync(join(root, 'letter.json'), JSON.stringify(document, null, 2) + '\n', 'utf8');
