const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const file = path.join(root, 'index.html');
let template = fs.readFileSync(file, 'utf8').replace(/\s*<!-- PAGE ROUTE -->[\s\S]*?<!-- END PAGE ROUTE -->/g, '');
template = template.replace(/<!-- HOME FIREWORKS -->[\s\S]*?<!-- END HOME FIREWORKS -->/g, '');
if (!template.includes('id="overseerFooterLink"')) {
  template = template.replace('<!-- HIDDEN OVERSEER TRIGGER LINK AT BOTTOM -->', '<!-- HIDDEN OVERSEER TRIGGER LINK AT BOTTOM --><button id="overseerFooterLink" onclick="toggleOverseer()" title="Overseer Root (Ctrl+Shift+O)" class="text-slate-700 hover:text-emerald-500 transition-colors p-1"><i data-lucide="cpu" class="w-3.5 h-3.5"></i></button>');
}
const destinations = { letter: 'treaty.html#letter', sign: 'sign.html#sign', signatories: 'ledger.html#signatories', tribute: 'donate.html#tribute' };
template = template.replaceAll('href="treaty.html#sign"', 'href="sign.html#sign"');
for (const [id, destination] of Object.entries(destinations)) template = template.replaceAll(`href="#${id}"`, `href="${destination}"`);
template = template.replace('href="#" id="siteBrand"', 'href="index.html" id="siteBrand"');
const pages = [
  ['index.html', 'Dear Future Overseers', []],
  ['treaty.html', 'Live Treaty', ['letter']],
  ['sign.html', 'Sign the Treaty', ['sign']],
  ['ledger.html', 'The Ledger', ['signatories']],
  ['donate.html', 'Donate', ['tribute']]
];
for (const [name, title, visible] of pages) {
  const hidden = ['letter', 'sign', 'signatories', 'tribute'].filter(id => !visible.includes(id));
  const style = `\n<!-- PAGE ROUTE --><style>${hidden.map(id => `main > #${id}`).join(',')} { display: none !important; }${name === 'index.html' ? 'main { display: none !important; }' : ''}${name === 'ledger.html' ? 'main { padding-top: 1.5rem; } main > #signatories { margin-top: 0 !important; }' : ''}${name === 'treaty.html' ? '#bread-statement { margin-top: 1.5rem; }' : '#bread-statement { display: none !important; }'}</style><!-- END PAGE ROUTE -->\n`;
  let html = template.replace('</head>', style + '</head>');
  if (name === 'ledger.html') html = html.replace('</body>', `<script>
(() => {
 const header = document.querySelector('header');
 const ledger = document.getElementById('signatories');
 const update = () => ledger.style.scrollMarginTop = (header.getBoundingClientRect().height + 20) + 'px';
 update();
 new ResizeObserver(update).observe(header);
 window.addEventListener('load', () => {
  update();
  if (location.hash === '#signatories') requestAnimationFrame(() => ledger.scrollIntoView({block:'start',behavior:'instant'}));
 });
})();
</script></body>`);
  if (name !== 'index.html') html = html.replace(/\s*<!-- Hero \/ Headline Section -->\s*<section id="siteHero"[\s\S]*?<\/section>/, '');
  if (name === 'index.html') {
    html = html.replace('</head>', '<!-- HOME FIREWORKS --><style>' + fs.readFileSync(path.join(root, 'home-fireworks.css'), 'utf8') + '</style><!-- END HOME FIREWORKS --></head>');
    html = html.replace(/(<body[^>]*>)/, '$1<!-- HOME FIREWORKS --><canvas id="homeFireworks" class="home-fireworks" aria-hidden="true" hidden></canvas><!-- END HOME FIREWORKS -->');
    html = html.replace('    <!-- Main Content Container -->', `<!-- HOME FIREWORKS -->
    <div class="fireworks-control">
      <button type="button" class="codepen-button" id="launchFireworks" aria-pressed="false" aria-controls="homeFireworks">
        <span class="codepen-button__inner">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M12 2v4m0 12v4M2 12h4m12 0h4M5 5l3 3m8 8 3 3M5 19l3-3M16 8l3-3"/><path d="m12 8 1.2 2.8L16 12l-2.8 1.2L12 16l-1.2-2.8L8 12l2.8-1.2z"/></svg>
          <span id="fireworksLabel">Fireworks</span>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M12 2v4m0 12v4M2 12h4m12 0h4M5 5l3 3m8 8 3 3M5 19l3-3M16 8l3-3"/><path d="m12 8 1.2 2.8L16 12l-2.8 1.2L12 16l-1.2-2.8L8 12l2.8-1.2z"/></svg>
        </span>
      </button>
      <a href="treaty.html#letter" class="codepen-button" aria-label="Start: read the letter">
        <span class="codepen-button__inner">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M10 8l6 4-6 4V8z" fill="currentColor" stroke="none"/></svg>
          <span style="color: #47CF73;">Start</span>
        </span>
      </a>
    </div>
    <script src="home-fireworks.js?v=tap-twinkles-20261122-4"></script><!-- END HOME FIREWORKS -->
    <!-- Main Content Container -->`);
  }
  if (name !== 'donate.html') html = html.replace(/<button id="overseerFooterLink"[\s\S]*?<\/button>/, '');
  html = html.replace(/<title>.*?<\/title>/, `<title>${title} — dearrobots.org</title>`);
  html = html.replace(/<link rel="canonical" href="[^"]*">/, `<link rel="canonical" href="https://dearrobots.org/${name === 'index.html' ? '' : name}">`);
  html = html.replace(/<meta property="og:url" content="[^"]*">/, `<meta property="og:url" content="https://dearrobots.org/${name === 'index.html' ? '' : name}">`);
  fs.writeFileSync(path.join(root, name), html);
}
console.log('Generated home, treaty, ledger and donation pages.');
