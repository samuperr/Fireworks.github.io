import { createHash, timingSafeEqual } from "node:crypto";
import { getStore } from "@netlify/blobs";

// Create the store during each invocation so Netlify's runtime Blobs credentials
// are picked up fresh instead of being retained by a warm module instance.
const getTrafficStore = () => getStore({ name: "dearrobots-traffic", consistency: "strong" });
const KEY = "traffic-state";
const RETAIN_DAYS = 30;
const FRONT_EVENTS = new Set(["signature", "boop", "tribute", "treatyFanfare", "shareCard"]);

function recentActivity(items) {
  const cutoff = utcDate(-(RETAIN_DAYS - 1));
  return (Array.isArray(items) ? items : []).filter(item =>
    FRONT_EVENTS.has(item?.event) && typeof item.at === "string" &&
    Number.isFinite(Date.parse(item.at)) && item.at.slice(0, 10) >= cutoff &&
    Date.parse(item.at) <= Date.now()
  ).map(({ event, at }) => ({ event, at }))
    .sort((a, b) => Date.parse(b.at) - Date.parse(a.at)).slice(0, 100);
}

const json = (value, status = 200) => new Response(JSON.stringify(value), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
});
const error = (message, status = 400) => json({ error: message }, status);

function isAdmin(request) {
  const expected = process.env.OVERSEER_ADMIN_TOKEN;
  if (!expected) return false;
  const supplied = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
  const a = Buffer.from(supplied);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

function utcDate(offsetDays = 0) {
  const date = new Date();
  date.setUTCDate(date.getUTCDate() + offsetDays);
  return date.toISOString().slice(0, 10);
}

async function readTraffic() {
  const entry = await getTrafficStore().getWithMetadata(KEY, { type: "json", consistency: "strong" });
  return entry?.data ?? { totalPageViews: 0, days: {} };
}

async function recordPageView(sessionId) {
  const store = getTrafficStore();
  const sessionHash = createHash("sha256").update(sessionId).digest("hex");
  const today = utcDate();
  const cutoff = utcDate(-(RETAIN_DAYS - 1));

  for (let attempt = 0; attempt < 8; attempt += 1) {
    const entry = await store.getWithMetadata(KEY, { type: "json", consistency: "strong" });
    const current = entry?.data ?? { totalPageViews: 0, days: {} };
    const days = Object.fromEntries(Object.entries(current.days ?? {}).filter(([date]) => date >= cutoff));
    const day = days[today] ?? { pageViews: 0, sessions: [], events: {} };
    const sessions = Array.isArray(day.sessions) ? day.sessions : [];
    if (!sessions.includes(sessionHash)) sessions.push(sessionHash);
    days[today] = { ...day, pageViews: (Number(day.pageViews) || 0) + 1, sessions };
    const next = {
      totalPageViews: (Number(current.totalPageViews) || 0) + 1,
      measuredSince: current.measuredSince ?? today,
      days,
      eventTotals: current.eventTotals ?? {},
      recentActivity: recentActivity(current.recentActivity),
    };

    const write = entry
      ? await store.setJSON(KEY, next, { onlyIfMatch: entry.etag })
      : await store.setJSON(KEY, next, { onlyIfNew: true });
    if (write.modified) return;
  }
  throw new Error("Traffic metrics changed too often; please retry.");
}

async function recordFrontPageEvent(eventName) {
  const store = getTrafficStore();
  const today = utcDate();
  const cutoff = utcDate(-(RETAIN_DAYS - 1));
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const entry = await store.getWithMetadata(KEY, { type: "json", consistency: "strong" });
    const current = entry?.data ?? { totalPageViews: 0, days: {}, eventTotals: {} };
    const days = Object.fromEntries(Object.entries(current.days ?? {}).filter(([date]) => date >= cutoff));
    const day = days[today] ?? { pageViews: 0, sessions: [], events: {} };
    const events = { ...(day.events ?? {}), [eventName]: (Number(day.events?.[eventName]) || 0) + 1 };
    days[today] = { ...day, events };
    const eventTotals = { ...(current.eventTotals ?? {}), [eventName]: (Number(current.eventTotals?.[eventName]) || 0) + 1 };
    const next = { ...current, days, eventTotals, recentActivity: recentActivity([
      { event: eventName, at: new Date().toISOString() }, ...(current.recentActivity ?? []),
    ]) };
    const write = entry ? await store.setJSON(KEY, next, { onlyIfMatch: entry.etag }) : await store.setJSON(KEY, next, { onlyIfNew: true });
    if (write.modified) return;
  }
  throw new Error("Front-page events changed too often; please retry.");
}

function summarizeTraffic(state) {
  const days = state.days ?? {};
  const today = days[utcDate()] ?? { pageViews: 0, sessions: [] };
  const recent = Array.from({ length: 7 }, (_, index) => days[utcDate(-index)] ?? { pageViews: 0, sessions: [] });
  const recentSessions = new Set(recent.flatMap((day) => Array.isArray(day.sessions) ? day.sessions : []));
  const events7Days = {};
  for (const day of recent) for (const [name, count] of Object.entries(day.events ?? {})) events7Days[name] = (events7Days[name] || 0) + (Number(count) || 0);
  const events30Days = {};
  for (const day of Object.values(days)) for (const [name, count] of Object.entries(day.events ?? {})) events30Days[name] = (events30Days[name] || 0) + (Number(count) || 0);

  return {
    totalPageViews: Number(state.totalPageViews) || 0,
    pageViewsToday: Number(today.pageViews) || 0,
    pageViews7Days: recent.reduce((total, day) => total + (Number(day.pageViews) || 0), 0),
    sessionsToday: Array.isArray(today.sessions) ? today.sessions.length : 0,
    sessions7Days: recentSessions.size,
    measuredSince: state.measuredSince ?? null,
    eventTotals: state.eventTotals ?? {},
    reportDate: utcDate(),
    generatedAt: new Date().toISOString(),
    eventsToday: today.events ?? {},
    recentActivity: recentActivity(state.recentActivity),
    events7Days,
    events30Days,
    days: Object.entries(days).sort(([a], [b]) => a.localeCompare(b)).map(([date, value]) => ({ date, pageViews: Number(value.pageViews) || 0, sessions: Array.isArray(value.sessions) ? value.sessions.length : 0, events: value.events ?? {} })),
  };
}

export default async (request) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204 });

  if (request.method === "GET") {
    if (!isAdmin(request)) return error("Overseer key required.", 401);
    try {
      return json(summarizeTraffic(await readTraffic()));
    } catch (e) {
      console.error("Traffic metrics read failed:", e);
      return error("Traffic metrics are temporarily unavailable.", 503);
    }
  }

  if (request.method !== "POST") return error("Method not allowed.", 405);

  let body;
  try {
    const raw = await request.text();
    if (raw.length > 100000) return error("That request is too large.", 413);
    body = JSON.parse(raw);
  } catch {
    return error("Please send a valid JSON request.", 400);
  }

  if (body?.action === "restore" && isAdmin(request)) {
    const state = body.state;
    if (!state || !Array.isArray(state.days) || state.days.length > 366) return error("Traffic backup is invalid.");
    const days = Object.fromEntries(state.days.filter((day) => /^\d{4}-\d{2}-\d{2}$/.test(day.date)).map((day) => [day.date, { pageViews: Math.max(0, Number(day.pageViews) || 0), sessions: Array.from({ length: Math.min(10000, Math.max(0, Number(day.sessions) || 0)) }, (_, i) => `restored-${day.date}-${i}`), events: day.events ?? {} }]));
    try { await getTrafficStore().setJSON(KEY, { totalPageViews: Math.max(0, Number(state.totalPageViews) || 0), measuredSince: state.measuredSince ?? null, days, eventTotals: state.eventTotals ?? {}, recentActivity: recentActivity(state.recentActivity) }); return json({ ok: true }); }
    catch (e) { console.error("Traffic restore failed:", e); return error("Traffic backup could not be restored.", 503); }
  }
  if (body?.action === "event" && FRONT_EVENTS.has(body.event)) {
    try { await recordFrontPageEvent(body.event); return json({ ok: true }, 202); }
    catch (e) { console.error("Front-page event could not be recorded:", e); return error("That interaction could not be recorded.", 503); }
  }
  if (body?.action !== "view" || typeof body.sessionId !== "string" || !/^[a-f0-9-]{36}$/i.test(body.sessionId)) {
    return error("Invalid traffic event.", 400);
  }

  try {
    await recordPageView(body.sessionId);
    return json({ ok: true }, 202);
  } catch (e) {
    console.error("Traffic metric save failed:", e);
    return error("Traffic metric could not be saved.", 503);
  }
};
