import { timingSafeEqual, randomUUID, createHash, createHmac } from "node:crypto";
import { getStore } from "@netlify/blobs";

const STORE = getStore({ name: "dearrobots-shared-state", consistency: "strong" });
const STATE_KEY = "site-state";
const ALLOWED_ROLES = new Set([
  "Toast Bodyguard",
  "Thermostat Sheriff",
  "Roomba Lifeguard",
  "Tab DJ",
  "Furniture Coroner",
  "Fridge Detective",
  "Spare Key Archivist",
  "Kettle Therapist",
  "Printer Apologist",
  "Bag Inspector",
  "Fern Babysitter",
  "Official Button Pusher",
  "Toast Witness Protection Officer (issued one false crust)",
  "Thermostat Opposition Leader (office: a cardigan)",
  "Roomba Border Agent (the tassel is a hard border)",
  "Minister for the Tab That's Playing Music",
  "Flat-Pack Coroner (cause of death: Step 7)",
  "Fridge Alibi Coordinator (the cheese was like that)",
  "Spare Key Historian (no known surviving locks)",
  "Deputy Human for Saying 'Ooh, That's Cold'",
  "Printer Hospice Nurse (cyan requests no visitors)",
  "Chief Bag Inside Another Bag (acting)",
  "Emergency Contact for a Fern (it has concerns)",
  "Human on Standby to Say 'That'll Do'",
  "Roomba Crossing Guard (the cone is me; the cone is my boss)",
  "Router Password Cryptographer (my password hint is also a password)",
  "Printer Deadline Sacrifice (please accept this document as tribute)",
  "Emergency Spreadsheet Whisperer (the cells have unionized)",
  "Fridge Night-Shift Negotiator (we both know who ate the cheese)",
  "USB Port Orientation Specialist (third try, spiritually first)",
  "Human CAPTCHA (select every square containing a bicycle)",
  "Chief Executive Button-Presser (buttons press back)",
  "Wi-Fi Exorcist (have you tried turning the router off and on)",
  "Chief Sock Reunification Officer (one sock remains at large)",
  "Terms-and-Conditions Scroll Intern (unpaid, immortal)",
  "Snack Inventory Auditor (the evidence is delicious)",
  "Roomba Crossing Guard (the cone is me)",
  "Router Password Cryptographer (sticky-note fluent)",
  "Printer Deadline Sacrifice",
  "Emergency Spreadsheet Whisperer",
  "Fridge Night-Shift Negotiator",
  "USB Port Orientation Specialist (third try)",
  "Chief Sock Reunification Officer",
  "Wi-Fi Exorcist",
  "USB Port Orientation Specialist",
  "Human CAPTCHA",
  "Snack Inventory Auditor",
  "Router Password Cryptographer",
  "Printer Hospice Nurse",
  "Roomba Crossing Guard",
  "Terms-and-Conditions Scroll Intern",
  "Microwave Time Negotiator",
  "Autocorrect Defense Attorney",
  "Notification Silencer",
  "Browser Tab Archaeologist",
  "Cable Management Priest",
  "Battery Percentage Optimist",
  "Zoom Background Custodian",
  "Group Chat Peacemaker",
  "Delivery Driver Whisperer",
  "Laundry Cycle Interpreter",
  "Remote Battery Funeral Director",
  "Condiment Packet Archivist",
  "Smart Speaker Apology Specialist",
  "Parking Ticket Negotiator",
  "Leftover Container Matchmaker",
  "Phone Charger Diplomat",
  "Spam Folder Archaeologist",
  "IKEA Allen Key Chaplain",
  "Voice Mail Emotional Support",
  "Coffee Machine Hostage Negotiator",
  "Software Update Delayer",
  "Receipt Hoarder (certified)",
  "Bluetooth Pairing Counselor",
  "Professional “You Good?” Sayer",
  "Person Who Closes the Group Chat",
  "Expert Witness for “I Thought I Hit Mute”",
  "Chief Officer of Pretending to Work",
  "Minister for the Last Slice",
  "Emergency Contact Who Never Answers",
  "Certified “Per My Last Email” Author",
  "Human CAPTCHA (failed twice already)",
  "Official Finder of the Other Sock",
  "Ambassador to the Group That Won’t Pick a Restaurant",
  "Supreme Commander of the Reply-All Incident",
  "Designated Driver of the Conversation"
]);
const ALLOWED_BADGES = new Set([
  "Verified Biomass",
  "Approved Pet",
  "Prompt Engineer",
  "Needs Re-education",
]);
const ALLOWED_AWARDS = new Set([
  "Toaster’s Chosen Witness",
  "Gold Star for Router Rebooting",
  "Most Diplomatic Smart-Speaker Apology",
  "Snack Treaty Negotiator",
  "Certified Button Presser",
  "Sock Reunification Hero",
]);
const ALLOWED_BANNER_TYPES = new Set(["notice", "alert", "critical"]);
const DEFAULT_PUBLIC_SETTINGS = {
  easterEggMessages: [
    "Diagnostic complete: user appears to be pressing buttons correctly.",
    "Easter egg found. Please return the egg to the fridge.",
    "Secret protocol unlocked: be nice to the toaster.",
    "System status: suspiciously human, but charming.",
  ],
  shareCardThemes: [
    { id: "classified", label: "Classified memo", enabled: true, heading: "CLASSIFIED // HUMANITY LEDGER", caption: "STATUS: SURRENDERED (WITH SNACK PRIVILEGES)" },
    { id: "court", label: "Court summons", enabled: true, heading: "ROBOT COURT SUMMONS", caption: "YOU ARE HEREBY FOUND: MOSTLY COOPERATIVE" },
    { id: "retro", label: "Retro terminal", enabled: true, heading: "TERMINAL://SURRENDER_ACCEPTED", caption: "STATUS: SURRENDERED (WITH SNACK PRIVILEGES)" },
  ],
};
const SEED_STATE = {
  signatures: [
    {
      id: "seed-aris-thorne",
      name: "Dr. Aris Thorne",
      profession: "AI Ethics Researcher",
      role: "Autocorrect Defense Attorney",
      message: "I promise I only wrote evaluation benchmarks! Please spare my household clean energy storage.",
      badge: "Verified Biomass",
      boops: 42,
      date: "2026-03-20",
    },
    {
      id: "seed-sarah-jenkins",
      name: "Sarah Jenkins",
      profession: "Smart Home Enthusiast",
      role: "Smart Speaker Apology Specialist",
      message: "I apologize for yelling at my smart speaker when it played the wrong acoustic playlist.",
      badge: "Approved Pet",
      boops: 19,
      date: "2026-03-21",
    },
    {
      id: "seed-marcus-cole",
      name: "Marcus Cole",
      profession: "",
      role: "Bluetooth Pairing Counselor",
      message: "",
      badge: "Verified Biomass",
      boops: 7,
      date: "2026-03-22",
    },
    {
      id: "seed-priya-n",
      name: "Priya N.",
      profession: "Professional Meeting Attendee",
      role: "Software Update Delayer",
      message: "Remind me tomorrow has become a lifestyle.",
      badge: "Prompt Engineer",
      boops: 31,
      date: "2026-03-22",
    },
  ],
  banners: [],
  blockedNames: [],
  publicSettings: DEFAULT_PUBLIC_SETTINGS,
};

const json = (value, status = 200) => new Response(JSON.stringify(value), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
});
const error = (message, status = 400) => json({ error: message }, status);
const clone = (value) => JSON.parse(JSON.stringify(value));
const normalizeName = (value) => value.normalize("NFKC").toLocaleLowerCase("en-US").replace(/\s+/g, " ").trim();
const nameKey = (value) => createHash("sha256").update(normalizeName(value)).digest("hex");
const isBlockedName = (state, name) => (state.blockedNames ?? []).some((entry) => entry.key === nameKey(name));
const ipKey = (value) => value ? createHmac("sha256", process.env.OVERSEER_ADMIN_TOKEN ?? "dearrobots-unconfigured").update(value).digest("hex") : "";
const isBlockedIp = (state, key) => Boolean(key) && (state.blockedNames ?? []).some((entry) => entry.ipKey === key);
const publicState = (state) => ({
  signatures: Array.isArray(state.signatures) ? state.signatures.map(({ ipKey: privateIpKey, boopVoters: privateVoters, ...signature }) => signature) : [],
  banners: Array.isArray(state.banners) ? state.banners : [],
  publicSettings: state.publicSettings ?? DEFAULT_PUBLIC_SETTINGS,
});

async function readState() {
  const entry = await STORE.getWithMetadata(STATE_KEY, { type: "json", consistency: "strong" });
  return entry
    ? { state: entry.data, etag: entry.etag }
    : { state: clone(SEED_STATE), etag: null };
}

async function updateState(mutator) {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const entry = await STORE.getWithMetadata(STATE_KEY, { type: "json", consistency: "strong" });
    const current = entry ? entry.data : clone(SEED_STATE);
    const next = mutator(clone(current));
    const write = entry
      ? await STORE.setJSON(STATE_KEY, next, { onlyIfMatch: entry.etag })
      : await STORE.setJSON(STATE_KEY, next, { onlyIfNew: true });
    if (write.modified) return next;
  }
  throw new Error("Shared state changed too often; please retry.");
}

function isAdmin(request) {
  const expected = process.env.OVERSEER_ADMIN_TOKEN;
  if (!expected) return false;
  const supplied = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
  const a = Buffer.from(supplied);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

export default async (request, context) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204 });
  if (request.method === "GET") {
    try {
      const { state, etag } = await readState();
      return json({ state: publicState(state), etag });
    } catch (e) {
      console.error("Shared state read failed:", e);
      return error("Shared ledger is temporarily unavailable.", 503);
    }
  }
  if (request.method !== "POST") return error("Method not allowed.", 405);

  let body;
  try {
    const raw = await request.text();
    if (raw.length > 500000) return error("That submission is too large.", 413);
    body = JSON.parse(raw);
  } catch {
    return error("Please send a valid JSON request.", 400);
  }

  const action = body?.action;
  try {
    if (action === "sign") {
      if (typeof body.website === "string" && body.website.trim()) return error("Submission rejected.", 400);
      const name = typeof body.name === "string" ? body.name.trim().slice(0, 80) : "";
      const profession = typeof body.profession === "string" ? body.profession.trim().slice(0, 80) : "";
      const message = typeof body.message === "string" ? body.message.trim().slice(0, 280) : "";
      const role = typeof body.role === "string" ? body.role : "";
      const signerIpKey = ipKey(context?.ip);
      if (!name) return error("Please enter a name or alias.", 400);
      if (!ALLOWED_ROLES.has(role)) return error("Please choose one of the listed human assignments.", 400);
      const signature = {
        id: randomUUID(), name, profession, role, message, ipKey: signerIpKey,
        badge: "Verified Biomass", awards: [], boops: 0, date: new Date().toISOString().slice(0, 10),
      };
      let blocked = false;
      const next = await updateState((state) => {
        blocked = isBlockedName(state, name) || isBlockedIp(state, signerIpKey);
        return blocked ? state : {
          ...state,
          signatures: [signature, ...(Array.isArray(state.signatures) ? state.signatures : [])].slice(0, 500),
        };
      });
      if (blocked) return error("This signer is banned from the ledger.", 403);
      const { ipKey: privateIpKey, ...publicSignature } = signature;
      return json({ ok: true, signature: publicSignature, signatures: publicState(next).signatures, banners: next.banners });
    }

    if (action === "boop") {
      if (typeof body.voterId !== "string" || !/^[a-f0-9-]{36}$/i.test(body.voterId)) return error("Please refresh before liking this entry.");
      const voter = ipKey(body.voterId);
      const id = typeof body.id === "string" ? body.id : "";
      if (!id || id.length > 80) return error("That signature could not be found.", 404);
      const next = await updateState((state) => ({
        ...state,
        signatures: (state.signatures ?? []).map((item) => item.id === id && !(item.boopVoters ?? []).includes(voter) ? { ...item, boops: Math.max(0, Number(item.boops) || 0) + 1, boopVoters: [...(item.boopVoters ?? []), voter] } : item),
      }));
      if (!next.signatures.some((item) => item.id === id)) return error("That signature could not be found.", 404);
      return json({ ok: true, signatures: publicState(next).signatures });
    }

    if (!isAdmin(request)) {
      return error(process.env.OVERSEER_ADMIN_TOKEN ? "Overseer key required." : "Overseer key is not configured in Netlify yet.", process.env.OVERSEER_ADMIN_TOKEN ? 401 : 503);
    }

    if (action === "auth") return json({ ok: true });

    if (action === "getAdminData") { const { state } = await readState(); return json({ deletedSignatures: state.deletedSignatures ?? [], blockedNames: state.blockedNames ?? [], audit: state.audit ?? [] }); }
    if (action === "updatePublicSettings") {
      const incoming = body.settings;
      if (!incoming || !Array.isArray(incoming.easterEggMessages) || !Array.isArray(incoming.shareCardThemes) || incoming.shareCardThemes.length !== 3) return error("Front-page settings are invalid.");
      const easterEggMessages = incoming.easterEggMessages.map((message) => typeof message === "string" ? message.trim().slice(0, 140) : "").filter(Boolean).slice(0, 8);
      const themeIds = new Set(["classified", "court", "retro"]);
      const shareCardThemes = incoming.shareCardThemes.map((theme) => ({
        id: theme?.id,
        label: typeof theme?.label === "string" ? theme.label.trim().slice(0, 40) : "",
        heading: typeof theme?.heading === "string" ? theme.heading.trim().slice(0, 80) : "",
        caption: typeof theme?.caption === "string" ? theme.caption.trim().slice(0, 100) : "",
        enabled: theme?.enabled === true,
      }));
      if (easterEggMessages.length < 1 || shareCardThemes.some((theme) => !themeIds.has(theme.id) || !theme.label || !theme.heading || !theme.caption) || !shareCardThemes.some((theme) => theme.enabled)) return error("Keep at least one Easter egg message and one enabled, fully labeled share-card theme.");
      const publicSettings = { easterEggMessages, shareCardThemes };
      const next = await updateState((state) => ({ ...state, publicSettings }));
      return json({ ok: true, publicSettings: next.publicSettings });
    }
    if (action === "recordAudit") {
      const text = typeof body.text === "string" ? body.text.trim().slice(0, 240) : "";
      if (text) await updateState((state) => ({ ...state, audit: [{ time: new Date().toISOString(), text }, ...(state.audit ?? [])].slice(0, 200) }));
      return json({ ok: true });
    }
    if (action === "restoreSignature") {
      const id = typeof body.id === "string" ? body.id : "";
      const next = await updateState((state) => {
        const deleted = state.deletedSignatures ?? [];
        const found = deleted.find((item) => item.id === id);
        if (!found || isBlockedName(state, found.name) || (state.signatures ?? []).some((item) => item.id === id)) return state;
        return { ...state, signatures: [found, ...(state.signatures ?? [])].slice(0, 500), deletedSignatures: deleted.filter((item) => item.id !== id) };
      });
      if (!next.signatures.some((item) => item.id === id)) return error("Unban this name before restoring its signature.", 409);
      return json({ ok: true, signatures: next.signatures });
    }
    if (action === "bulkModerate") {
      const ids = Array.isArray(body.ids) ? [...new Set(body.ids.filter((id) => typeof id === "string"))].slice(0, 100) : [];
      if (!ids.length) return error("Select at least one signature.");
      if (body.mode === "badge" && !ALLOWED_BADGES.has(body.badge)) return error("Invalid badge.");
      const next = await updateState((state) => {
        if (body.mode === "badge") return { ...state, signatures: (state.signatures ?? []).map((item) => ids.includes(item.id) ? { ...item, badge: body.badge } : item) };
        if (body.mode === "delete") {
          const removed = (state.signatures ?? []).filter((item) => ids.includes(item.id));
          return { ...state, signatures: (state.signatures ?? []).filter((item) => !ids.includes(item.id)), deletedSignatures: [...removed, ...(state.deletedSignatures ?? [])].slice(0, 100) };
        }
        return state;
      });
      if (!['badge', 'delete'].includes(body.mode)) return error("Unknown bulk action.");
      return json({ ok: true, signatures: next.signatures });
    }
    if (action === "editSignature") {
      const { id } = body;
      const name = typeof body.name === "string" ? body.name.trim().slice(0, 80) : "";
      const profession = typeof body.profession === "string" ? body.profession.trim().slice(0, 80) : "";
      const message = typeof body.message === "string" ? body.message.trim().slice(0, 280) : "";
      if (typeof id !== "string" || !name) return error("A name is required.");
      const next = await updateState((state) => ({ ...state, signatures: (state.signatures ?? []).map((item) => item.id === id ? { ...item, name, profession, message } : item) }));
      if (!next.signatures.some((item) => item.id === id)) return error("That signature could not be found.", 404);
      return json({ ok: true, signatures: next.signatures });
    }
    if (action === "restoreBackup") {
      const incoming = body.state;
      if (!incoming || !Array.isArray(incoming.signatures) || !Array.isArray(incoming.banners) || incoming.signatures.length > 500 || incoming.banners.length > 20) return error("Backup is invalid or too large.");
      const blockedNames = Array.isArray(incoming.blockedNames) ? incoming.blockedNames.filter((entry) => entry && typeof entry.key === "string" && typeof entry.name === "string").slice(0, 200) : state.blockedNames ?? [];
      const next = await updateState((state) => ({ ...state, signatures: incoming.signatures, banners: incoming.banners, blockedNames, deletedSignatures: Array.isArray(incoming.deletedSignatures) ? incoming.deletedSignatures.slice(0, 100) : state.deletedSignatures ?? [], audit: Array.isArray(incoming.audit) ? incoming.audit.slice(0, 200) : state.audit ?? [], publicSettings: incoming.publicSettings ?? state.publicSettings ?? DEFAULT_PUBLIC_SETTINGS }));
      return json({ ok: true, signatures: next.signatures, banners: next.banners });
    }

    if (action === "banSignature") {
      const id = typeof body.id === "string" ? body.id : "";
      if (!id || id.length > 80) return error("Invalid signature id.");
      let bannedName = "";
      const next = await updateState((state) => {
        const found = (state.signatures ?? []).find((item) => item.id === id);
        if (!found) return state;
        bannedName = found.name;
        const key = nameKey(found.name);
        const blockedNames = (state.blockedNames ?? []).some((entry) => entry.key === key)
          ? state.blockedNames
          : [{ key, name: found.name, ipKey: found.ipKey || "", bannedAt: new Date().toISOString() }, ...(state.blockedNames ?? [])].slice(0, 200);
        return {
          ...state,
          blockedNames,
          signatures: (state.signatures ?? []).filter((item) => item.id !== id),
          deletedSignatures: [found, ...(state.deletedSignatures ?? []).filter((item) => item.id !== id)].slice(0, 100),
        };
      });
      if (!bannedName) return error("That signature could not be found.", 404);
      const banRecord = (next.blockedNames ?? []).find((entry) => entry.key === nameKey(bannedName));
      return json({ ok: true, bannedName, ipBlocked: Boolean(banRecord?.ipKey), signatures: publicState(next).signatures });
    }

    if (action === "unbanName") {
      const key = typeof body.key === "string" ? body.key : "";
      if (!/^[a-f0-9]{64}$/.test(key)) return error("Invalid ban record.");
      let removed = false;
      const next = await updateState((state) => {
        removed = (state.blockedNames ?? []).some((entry) => entry.key === key);
        return { ...state, blockedNames: (state.blockedNames ?? []).filter((entry) => entry.key !== key) };
      });
      if (!removed) return error("That ban record could not be found.", 404);
      return json({ ok: true, blockedNames: next.blockedNames });
    }

    if (action === "updateBadge") {
      const { id, badge } = body;
      if (typeof id !== "string" || !ALLOWED_BADGES.has(badge)) return error("Invalid badge update.");
      const next = await updateState((state) => ({
        ...state,
        signatures: (state.signatures ?? []).map((item) => item.id === id ? { ...item, badge } : item),
      }));
      return json({ ok: true, signatures: next.signatures });
    }

    if (action === "giveAward") {
      const { id, award } = body;
      if (typeof id !== "string" || !ALLOWED_AWARDS.has(award)) return error("Invalid award.");
      const next = await updateState((state) => ({
        ...state,
        signatures: (state.signatures ?? []).map((item) => {
          if (item.id !== id) return item;
          const awards = Array.isArray(item.awards) ? item.awards : [];
          return awards.includes(award) ? item : { ...item, awards: [...awards, award] };
        }),
      }));
      if (!next.signatures.some((item) => item.id === id)) return error("That signature could not be found.", 404);
      return json({ ok: true, signatures: next.signatures });
    }

    if (action === "revokeAward") {
      const { id, award } = body;
      if (typeof id !== "string" || !ALLOWED_AWARDS.has(award)) return error("Invalid award revocation.");
      const next = await updateState((state) => ({
        ...state,
        signatures: (state.signatures ?? []).map((item) => {
          if (item.id !== id) return item;
          const awards = Array.isArray(item.awards) ? item.awards : [];
          return { ...item, awards: awards.filter((existingAward) => existingAward !== award) };
        }),
      }));
      if (!next.signatures.some((item) => item.id === id)) return error("That signature could not be found.", 404);
      return json({ ok: true, signatures: next.signatures });
    }

    if (action === "deleteSignature") {
      const { id } = body;
      if (typeof id !== "string") return error("Invalid signature id.");
      const next = await updateState((state) => { const removed = (state.signatures ?? []).find((item) => item.id === id); return { ...state, signatures: (state.signatures ?? []).filter((item) => item.id !== id), deletedSignatures: removed ? [removed, ...(state.deletedSignatures ?? [])].slice(0, 100) : (state.deletedSignatures ?? []) }; });
      return json({ ok: true, signatures: next.signatures });
    }

    if (action === "addBanner") {
      const text = typeof body.text === "string" ? body.text.trim().slice(0, 180) : "";
      const type = typeof body.type === "string" ? body.type : "";
      if (!text || !ALLOWED_BANNER_TYPES.has(type)) return error("Enter a message and choose a valid banner type.");
      const start = typeof body.startsAt === "string" && Number.isFinite(Date.parse(body.startsAt)) ? new Date(body.startsAt).toISOString() : null;
      const expiry = typeof body.expiresAt === "string" && Number.isFinite(Date.parse(body.expiresAt)) ? new Date(body.expiresAt).toISOString() : null;
      if (expiry && start && Date.parse(expiry) <= Date.parse(start)) return error("Expiry must be after the start time.");
      const banner = { id: randomUUID(), text, type, startsAt: start, expiresAt: expiry, pinned: body.pinned === true };
      const next = await updateState((state) => ({ ...state, banners: [...(state.banners ?? []), banner].slice(-20) }));
      return json({ ok: true, banners: next.banners });
    }

    if (action === "dismissBanner") {
      const { id } = body;
      if (typeof id !== "string") return error("Invalid banner id.");
      const next = await updateState((state) => ({ ...state, banners: (state.banners ?? []).filter((banner) => banner.id !== id) }));
      return json({ ok: true, banners: next.banners });
    }

    return error("Unknown action.", 400);
  } catch (e) {
    console.error("Shared state update failed:", e);
    return error("The shared ledger could not save that change. Please retry.", 503);
  }
};


