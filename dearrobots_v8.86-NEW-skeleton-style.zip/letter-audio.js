(() => {
    const read = document.getElementById('read-letter');
    const label = document.getElementById('read-letter-label');
    const stop = document.getElementById('stop-letter');
    const status = document.getElementById('letter-audio-status');
    const speech = window.speechSynthesis;

    if (!speech || !window.SpeechSynthesisUtterance) {
        read.disabled = true;
        status.textContent = 'Read aloud is unavailable in this browser.';
        return;
    }

    let state = 'idle';
    let current = null;
    let queue = [];
    let voice = null;
    const language = document.documentElement.lang || 'en';
    const languageFamily = language.split('-')[0].toLowerCase();

    // Some browsers populate their voice list asynchronously after the first query.
    speech.getVoices();

    function selectVoice() {
        const matching = speech.getVoices().filter(candidate =>
            candidate.lang.split(/[-_]/)[0].toLowerCase() === languageFamily
        );
        const natural = matching.filter(candidate =>
            /\b(natural|neural|enhanced|premium)\b|^Google /i.test(candidate.name)
        );
        return natural.find(candidate => candidate.lang.toLowerCase() === language.toLowerCase())
            || natural.find(candidate => candidate.default)
            || natural[0]
            || null;
    }

    function update(next, message) {
        state = next;
        read.dataset.state = next;
        label.textContent = { idle: 'Read aloud', reading: 'Pause', paused: 'Resume' }[next];
        stop.disabled = next === 'idle';
        status.textContent = message;
    }

    function reset(message) {
        current = null;
        queue = [];
        speech.cancel();
        update('idle', message);
    }

    function speakNext() {
        if (state !== 'reading') return;
        if (!queue.length) {
            update('idle', 'Reading finished.');
            return;
        }

        const utterance = new SpeechSynthesisUtterance(queue.shift());
        utterance.lang = voice?.lang || language;
        utterance.rate = 0.93;
        if (voice) utterance.voice = voice;
        current = utterance;
        utterance.onend = () => {
            if (current !== utterance) return;
            current = null;
            speakNext();
        };
        utterance.onerror = () => {
            if (current === utterance) reset('Playback failed. Try Read aloud again.');
        };
        speech.speak(utterance);
    }

    read.addEventListener('click', () => {
        if (state === 'reading') {
            update('paused', 'Reading paused.');
            speech.pause();
            return;
        }
        if (state === 'paused') {
            update('reading', 'Reading the letter.');
            speech.resume();
            if (!current) speakNext();
            return;
        }

        const paragraphs = document.querySelectorAll('#letter h2, #letter .letter-preamble p, #letter-body > p, .letter-article > h3, .letter-article > p, #letter-body li');
        const segmenter = typeof Intl.Segmenter === 'function'
            ? new Intl.Segmenter(language, { granularity: 'sentence' })
            : null;
        queue = Array.from(paragraphs).flatMap(paragraph => {
            const text = paragraph.textContent.trim();
            if (!segmenter || text.length <= 210) return [text];

            // Keep short sentences together so the voice can carry the rhythm across them.
            const passages = [];
            let passage = '';
            for (const { segment } of segmenter.segment(text)) {
                const sentence = segment.trim();
                if (passage && passage.length + sentence.length + 1 > 210) {
                    passages.push(passage);
                    passage = '';
                }
                passage = passage ? passage + ' ' + sentence : sentence;
            }
            if (passage) passages.push(passage);
            return passages;
        }).filter(Boolean);
        voice = selectVoice();
        speech.resume();
        update('reading', 'Reading the letter.');
        speakNext();
    });

    stop.addEventListener('click', () => {
        reset('Reading stopped.');
        read.focus();
    });
    window.addEventListener('pagehide', () => {
        if (state !== 'idle') reset('');
    });
})();
