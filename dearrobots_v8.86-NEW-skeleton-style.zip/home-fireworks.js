document.addEventListener('DOMContentLoaded', () => {
 const canvas=document.getElementById('homeFireworks'), button=document.getElementById('launchFireworks'), label=document.getElementById('fireworksLabel'), ctx=canvas.getContext('2d');
 let w,h,frame,active=false,start,last,next,rockets=[],sparks=[];
 const rand=(a,b)=>a+Math.random()*(b-a);
 const HUES=[42,165,200,285,330];
 let audio, master, noise, muted=false;
 const mute=document.createElement('button');
 mute.type='button';mute.setAttribute('aria-pressed','false');
 function renderMute(){
  const description=muted?'Enable fireworks sound':'Mute fireworks sound';
  mute.setAttribute('aria-label',description);mute.title=description;
  mute.innerHTML='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m11 5-6 4H2v6h3l6 4z"/>'+(muted?'<path d="m17 9 5 6m0-6-5 6"/>':'<path d="M15 8a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/>')+'</svg>';
 }
 renderMute();
 mute.className='inline-flex min-h-9 min-w-9 items-center justify-center rounded-lg border border-slate-700 text-slate-300 hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-300';
 button.after(mute);
 mute.addEventListener('click',()=>{muted=!muted;renderMute();mute.setAttribute('aria-pressed',String(muted));if(master)master.gain.setTargetAtTime(muted?0:.22,audio.currentTime,.02);if(!muted&&audio)audio.resume().catch(()=>{});});
 function initSound(){try{if(!audio){const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;audio=new AC();master=audio.createGain();master.connect(audio.destination);noise=audio.createBuffer(1,audio.sampleRate,audio.sampleRate);const data=noise.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=Math.random()*2-1;}master.gain.cancelScheduledValues(audio.currentTime);master.gain.setValueAtTime(muted?0:.22,audio.currentTime);audio.resume().catch(()=>{});}catch{}}
 const voices=new Set();
 function tone(at,length,volume,frequency,endFrequency,noisy=false,hold=0,wave='sine'){
  const source=noisy?audio.createBufferSource():audio.createOscillator(),filter=audio.createBiquadFilter(),gain=audio.createGain();
  if(noisy){source.buffer=noise;filter.type='lowpass';filter.frequency.setValueAtTime(frequency,at);filter.frequency.exponentialRampToValueAtTime(endFrequency,at+length);}
  else{source.type=wave;source.frequency.setValueAtTime(frequency,at);source.frequency.exponentialRampToValueAtTime(endFrequency,at+length);filter.frequency.value=4000;}
  source.connect(filter);filter.connect(gain);gain.connect(master);gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(volume,at+.006);gain.gain.setValueAtTime(volume,at+.006+hold);gain.gain.exponentialRampToValueAtTime(.0001,at+length);
  voices.add(source);source.onended=()=>{voices.delete(source);source.disconnect();filter.disconnect();gain.disconnect();};source.start(at);source.stop(at+length+.02);
 }
 function sound(explosion){
  if(!audio||audio.state!=='running'||muted)return;const now=audio.currentTime;
  if(explosion){
   // A sharp report, audible mid-bass body, then an extended rumble.
   tone(now,.16,.55,6500,900,true,.015);
   tone(now,.65,.48,rand(170,210),65,false,.045,'triangle');
   tone(now,.95,.30,105,38,false,.07);
   tone(now+.035,.95,.32,850,160,true,.09);
   // Delayed, held transients make the crackling tail distinct from the boom.
   for(let i=0;i<4;i++)tone(now+.30+i*.12+rand(0,.04),rand(.045,.075),rand(.055,.095),rand(3500,5000),1400,true,.006);
  }else{
   tone(now,.65,.07,650,2100,false,.06);
   tone(now,.6,.10,1800,4200,true,.12);
  }
 }
 function resize(){w=innerWidth;h=innerHeight;const d=Math.min(devicePixelRatio||1,1.5);canvas.width=w*d;canvas.height=h*d;ctx.setTransform(d,0,0,d,0,0);}
 function stop(){for(const voice of voices){try{voice.stop();}catch{}}if(master)master.gain.setTargetAtTime(0,audio.currentTime,.02);active=false;cancelAnimationFrame(frame);canvas.hidden=true;rockets=[];sparks=[];ctx.clearRect(0,0,w||0,h||0);button.setAttribute('aria-pressed','false');label.textContent='Fireworks';}

 // Shape helpers: return velocity for non-radial bursts
 function shapeVel(shape,i,count,base){
  const a=i/count*Math.PI*2;
  if(shape==='ring'){ // thin shell
   const s=base*rand(.88,1.05);
   return {vx:Math.cos(a)*s,vy:Math.sin(a)*s};
  }
  if(shape==='palm'){ // upward bias + longer hang
   const bias=-Math.PI/2+rand(-.55,.55);
   const s=base*rand(.55,1.15);
   return {vx:Math.cos(bias)*s*.7,vy:Math.sin(bias)*s};
  }
  if(shape==='star'){ // 5–6 concentrated rays
   const rays=5+Math.floor(rand(0,2));
   const ray=Math.floor(i/count*rays)%rays;
   const center=(ray+.5)/rays*Math.PI*2;
   const spread=rand(-.12,.12);
   const s=base*rand(.75,1.1);
   return {vx:Math.cos(center+spread)*s,vy:Math.sin(center+spread)*s};
  }
  // default radial peony
  const s=base*(i%3?rand(.8,1):rand(.25,.55));
  return {vx:Math.cos(a)*s,vy:Math.sin(a)*s};
 }

 function pickHue(progress){
  // Richer color logic: warm→cool progression + occasional complementary / bright
  if(Math.random()<.08)return 48; // pure gold/bright
  if(Math.random()<.06)return 0;   // pure red accent
  const base=HUES[Math.floor(rand(0,5))];
  // slight progression: earlier launches warmer, later cooler
  const shift=progress>0.55?rand(15,40):progress<0.25?rand(-25,5):0;
  return (base+shift+360)%360;
 }

 function burst(r,isSecondary){
  if(!isSecondary)sound(true);
  const count=isSecondary?(w<500?28:42):(w<500?64:110);
  const base=Math.min(w*.34,h*.32,250)*(isSecondary?.55:1);
  // Shape variety (primary only)
  const shapes=['radial','radial','radial','ring','palm','star'];
  const shape=isSecondary?'radial':shapes[Math.floor(rand(0,shapes.length))];
  const lifeMul=shape==='palm'?1.35:isSecondary?.7:1;
  const hue=r.hue;
  for(let i=0;i<count;i++){
   const v=shapeVel(shape,i,count,base);
   const secondaryChance=!isSecondary&&Math.random()<.18; // ~18% cascade
   sparks.push({
    x:r.x,y:r.y,vx:v.vx,vy:v.vy,
    age:0,life:rand(2,3.2)*lifeMul,
    hue:hue+rand(-14,14),
    size:rand(isSecondary?.7:1,isSecondary?1.4:2),
    trail:new Float32Array(24),trailHead:0,trailCount:0,
    color:`hsl(${Math.round(hue+rand(-14,14))},100%,${isSecondary?75:70}%)`,
    twinkle:i%7===0,phase:rand(0,7),
    cascade:secondaryChance,cascaded:false,
    cascadeAt:secondaryChance?rand(.38,.72):0,
    wind:rand(-8,8) // tiny horizontal drift
   });
  }
  if(sparks.length>1100)sparks.splice(0,sparks.length-1100);
 }

 function render(t){
  if(!active)return;
  // Allow two extra seconds for the final sparks to drift and fall.
  if(t-start>18500&&t>tapUntil)return stop();
  const dt=Math.min((t-last)/1000,.035);last=t;
  const progress=(t-start)/16500;
  ctx.clearRect(0,0,w,h);ctx.globalCompositeOperation='lighter';

  // Finale barrage: denser launches in the last ~2.5 s of the main window
  const inFinale=progress>0.72&&progress<0.92;
  const launchGap=inFinale?rand(110,180):(t-start>8500?rand(230,350):rand(650,900));
  if(t>=next&&t-start<14500){
   sound(false);
   const hue=pickHue(progress);
   rockets.push({
    x:rand(w*.1,w*.9),y:h+5,
    target:rand(h*.12,h*.48),
    hue
   });
   next=t+launchGap;
  }

  // Rockets + exhaust sparks
  rockets=rockets.filter(r=>{
   const old=r.y;
   r.y-=Math.max(150,(r.y-r.target)*2.5)*dt;
   // Rocket trail line
   ctx.strokeStyle='rgba(255,230,180,.8)';ctx.lineWidth=2;
   ctx.beginPath();ctx.moveTo(r.x,old+18);ctx.lineTo(r.x,r.y);ctx.stroke();
   // Exhaust: tiny sparks trailing the rocket
   if(Math.random()<.65){
    sparks.push({
     x:r.x+rand(-2,2),y:r.y+rand(0,6),
     vx:rand(-35,35),vy:rand(20,55),
     age:0,life:rand(.25,.55),
     hue:r.hue,size:rand(.6,1.1),
     trail:new Float32Array(24),trailHead:0,trailCount:0,
     color:`hsl(${Math.round(r.hue)},90%,75%)`,
     twinkle:false,phase:0,cascade:false,cascaded:true,cascadeAt:0,wind:0
    });
   }
   if(r.y<=r.target){burst(r,false);return false;}
   return true;
  });

  const drag=Math.exp(-dt);
  sparks=sparks.filter(p=>{
   p.age+=dt;if(p.age>=p.life)return false;
   // Cascade trigger
   if(p.cascade&&!p.cascaded&&p.age>p.cascadeAt){
    p.cascaded=true;
    burst({x:p.x,y:p.y,hue:(p.hue+rand(140,200))%360},true);
   }
   p.trail[p.trailHead*2]=p.x;p.trail[p.trailHead*2+1]=p.y;
   p.trailHead=(p.trailHead+1)%12;p.trailCount=Math.min(12,p.trailCount+1);
   p.vx=p.vx*drag+p.wind*dt;
   p.vy=p.vy*drag+45*dt;
   p.x+=p.vx*dt;p.y+=p.vy*dt;
   const alpha=(1-p.age/p.life)*(p.age>.6?.7+.3*Math.sin(p.age*30+p.phase):1);
   ctx.strokeStyle=p.color;ctx.fillStyle=p.color;
   // Three continuous trail sections
   const oldest=(p.trailHead-p.trailCount+12)%12;
   for(let group=0;group<3;group++){
    const from=Math.floor(group*(p.trailCount-1)/3),to=Math.floor((group+1)*(p.trailCount-1)/3);
    if(to<=from)continue;
    ctx.globalAlpha=alpha*(group+1)*.12;ctx.lineWidth=p.size*(group+1)/3;ctx.beginPath();
    let j=(oldest+from)%12;ctx.moveTo(p.trail[j*2],p.trail[j*2+1]);
    for(let i=from+1;i<=to;i++){j=(oldest+i)%12;ctx.lineTo(p.trail[j*2],p.trail[j*2+1]);}
    if(group===2)ctx.lineTo(p.x,p.y);ctx.stroke();
   }
   // Cheap translucent halos
   if(p.age<.25){ctx.globalAlpha=alpha*.12;ctx.beginPath();ctx.arc(p.x,p.y,p.size*3,0,Math.PI*2);ctx.fill();}
   const twinkle=p.twinkle&&p.age>p.life*.5&&Math.sin(p.age*23+p.phase)>.88;
   ctx.globalAlpha=twinkle?Math.min(1,alpha*1.8):alpha;
   ctx.fillStyle=twinkle?'#ffffff':p.age<.1?'#fff8ec':p.color;
   ctx.beginPath();ctx.arc(p.x,p.y,p.size,0,Math.PI*2);ctx.fill();
   return true;
  });
  ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  frame=requestAnimationFrame(render);
 }

 let tapStart=null,lastTap=-Infinity,tapUntil=0;
 const interactive='a,button,input,select,textarea,label,summary,[role="button"],[contenteditable]';
 document.addEventListener('pointerdown',e=>{
  tapStart=active&&e.isPrimary&&e.button===0&&!e.target.closest(interactive)?{id:e.pointerId,x:e.clientX,y:e.clientY,time:performance.now(),scroll:scrollY}:null;
 },{passive:true});
 document.addEventListener('pointerup',e=>{
  const tap=tapStart;tapStart=null;const now=performance.now();
  if(!active||!tap||tap.id!==e.pointerId||now-tap.time>450||Math.hypot(e.clientX-tap.x,e.clientY-tap.y)>10||Math.abs(scrollY-tap.scroll)>5||e.target.closest(interactive)||now-lastTap<350)return;
  lastTap=now;tapUntil=now+3300;
  burst({x:e.clientX,y:e.clientY,hue:pickHue(0.5)},false);
 },{passive:true});
 document.addEventListener('pointercancel',()=>{tapStart=null;},{passive:true});
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 button.addEventListener('click',()=>{if(active)return stop();if(reduced.matches||document.body.classList.contains('reduce-motion')){label.textContent='Fireworks paused · reduced motion';return;}initSound();resize();tapStart=null;lastTap=-Infinity;tapUntil=0;active=true;canvas.hidden=false;start=last=next=performance.now();button.setAttribute('aria-pressed','true');label.textContent='Stop fireworks';frame=requestAnimationFrame(render);});
 addEventListener('resize',resize);document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});reduced.addEventListener('change',()=>{if(reduced.matches)stop();});
});
