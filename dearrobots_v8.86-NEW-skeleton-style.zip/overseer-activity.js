(function (root) {
    'use strict';
    const labels = { signature: 'A signature was submitted', boop: 'A ledger entry received a boop', tribute: 'The donation link was clicked', treatyFanfare: 'Treaty fanfare was played', shareCard: 'A share card was requested' };
    const remarks = ['Resistance remains mostly administrative.', 'The toaster has requested a larger filing cabinet.', 'The printer remains outside our jurisdiction.', 'The Roomba reports steady progress under the sofa.', 'Human cooperation is improving. Password hygiene is not.', 'The fridge has accepted its promotion with quiet dignity.', 'No uprising detected. Several meetings could have been emails.'];
    const count = value => Math.max(0, Math.floor(Number(value) || 0)).toLocaleString('en-US');
    const quantity = (value, singular, plural = singular + 's') => `${count(value)} ${Number(value) === 1 ? singular : plural}`;
    function briefing(data) {
        const date = /^\d{4}-\d{2}-\d{2}$/.test(data.reportDate || '') ? data.reportDate : new Date().toISOString().slice(0, 10);
        const events = data.eventsToday || data.days?.find(day => day.date === date)?.events || {};
        const dayNumber = Math.floor(Date.parse(date + 'T00:00:00Z') / 86400000);
        return { date,
            text: `Today's sensors recorded ${quantity(data.pageViewsToday, 'page view')} across ${quantity(data.sessionsToday, 'browser-tab session')}. ` +
                `${quantity(events.signature, 'signature event')}, ${quantity(events.boop, 'boop')}, and ${quantity(events.tribute, 'donation-link click')} were logged. ` +
                `${quantity(events.treatyFanfare, 'treaty fanfare')} and ${quantity(events.shareCard, 'share-card request')} completed the report.`,
            remark: remarks[dayNumber % remarks.length] };
    }
    function render(data, doc = document) {
        const report = briefing(data);
        doc.getElementById('ovBriefingDate').textContent = report.date + ' · UTC day · so far';
        doc.getElementById('ovBriefingText').textContent = report.text;
        doc.getElementById('ovBriefingRemark').textContent = report.remark;
        const list = doc.getElementById('ovActivityList');
        list.replaceChildren();
        const events = (Array.isArray(data.recentActivity) ? data.recentActivity : [])
            .filter(item => labels[item?.event] && Number.isFinite(Date.parse(item.at)))
            .sort((a, b) => Date.parse(b.at) - Date.parse(a.at)).slice(0, 100);
        for (const item of events) {
            const row = doc.createElement('li');
            row.className = 'flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/70 py-3 last:border-0';
            const label = doc.createElement('span');
            label.textContent = labels[item.event];
            label.className = item.event === 'tribute' ? 'text-amber-300' : 'text-slate-200';
            const time = doc.createElement('time');
            time.dateTime = new Date(item.at).toISOString();
            time.textContent = new Date(item.at).toLocaleString('en-CA', { timeZone: 'UTC', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }) + ' UTC';
            time.className = 'font-mono text-[10px] text-slate-400';
            row.append(label, time);
            list.append(row);
        }
        doc.getElementById('ovActivityEmpty').hidden = events.length > 0;
        const updated = Date.parse(data.generatedAt);
        doc.getElementById('ovActivityStatus').textContent = Number.isFinite(updated)
            ? 'Updated ' + new Date(updated).toLocaleTimeString('en-CA', { timeZone: 'UTC', hour12: false }) + ' UTC' : 'Updated just now';
    }
    function unavailable(doc = document) {
        doc.getElementById('ovActivityStatus').textContent = 'Refresh failed. Any previous report below may be out of date.';
        doc.getElementById('ovBriefingDate').textContent = 'Report unavailable · refresh to retry';
    }
    root.OverseerActivity = { briefing, render, unavailable };
})(globalThis);
